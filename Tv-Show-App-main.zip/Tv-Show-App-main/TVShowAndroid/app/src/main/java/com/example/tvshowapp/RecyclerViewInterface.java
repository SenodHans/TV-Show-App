package com.example.tvshowapp;

import com.example.tvshowapp.model.TvShow;

public interface RecyclerViewInterface {

    public void onItemClick(int position);
}
